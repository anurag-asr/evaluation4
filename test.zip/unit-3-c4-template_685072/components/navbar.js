let navbar=()=>{
    return `
   
    <h2><a href="index.html">NewsApp</a></h2>
    <input type="text" placeholder="Search News" id="search_input">

       
        `
}
export {navbar};


// <div id="sidebar">
// <h2>countries</h2>
// <button id="india">India</button><br>
// <button id="china">China</button><br>
// <button id="usa">USA</button><br>
// <button id="united_kingdom">United kingdom</button><br>
// <button id="newzealand">Newzeland</button><br>
// </div>